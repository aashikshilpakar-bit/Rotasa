/* Rasato Fine Grooming site scripts */

var BARBER_DATA = {
  angel: {
    name: "Angel",
    services: [
      { name: "Young gentlemen (12+)", duration: "30 min", price: 35 },
      { name: "Beard Trim", duration: "30 min", price: 25 },
      { name: "Line Up", duration: "30 min", price: 25 },
      { name: "Line Up & Beard", duration: "30 min", price: 40 },
      { name: "The full Rasato Experience", duration: "1 hr", price: 80 },
      { name: "Haircut and beard", duration: "1 hr", price: 55 },
      { name: "Haircut", duration: "45 min", price: 40 }
    ]
  },
  abigail: {
    name: "Abigail M.",
    services: [
      { name: "Modern Classic", duration: "30 min", price: 40 },
      { name: "Haircut and Beard Trim", duration: "45 min", price: 55 },
      { name: "Young gentlemen (12+)", duration: "30 min", price: 35 },
      { name: "Beard Trim", duration: "30 min", price: 25 },
      { name: "Line Up", duration: "30 min", price: 25 },
      { name: "The full Rasato Experience", duration: "1 hr", price: 80 },
      { name: "Line Up & Beard", duration: "30 min", price: 40 },
      { name: "The Rasato - Signature", duration: "30 min", price: 55 }
    ]
  },
  ryan: {
    name: "Ryan W.",
    services: [
      { name: "Modern Classic", duration: "30 min", price: 40 },
      { name: "Haircut and Beard Trim", duration: "45 min", price: 55 },
      { name: "Young gentlemen (12+)", duration: "30 min", price: 35 },
      { name: "Beard Trim", duration: "30 min", price: 25 },
      { name: "Line Up", duration: "30 min", price: 25 },
      { name: "Line Up & Beard", duration: "30 min", price: 40 },
      { name: "The Rasato - Signature", duration: "30 min", price: 55 },
      { name: "The full Rasato Experience", duration: "1 hr", price: 80 },
      { name: "Women's Haircut", duration: "45 min", price: 55 }
    ]
  },
  savina: {
    name: "Savina A.",
    services: [
      { name: "Modern classic haircut", duration: "30 min", price: 50 },
      { name: "Modern classic combo/service", duration: "45 min", price: 60 },
      { name: "Young gentlemen", duration: "30 min", price: 40 },
      { name: "Beard trim", duration: "30 min", price: 30 },
      { name: "Senior Gentleman's", duration: "30 min", price: 45 },
      { name: "Base cut", duration: "30 min", price: 45 }
    ]
  },
  pasquale: {
    name: "Pasquale",
    services: [
      { name: "Modern classic haircut", duration: "30 min", price: 50 },
      { name: "Modern classic combo/service", duration: "45 min", price: 60 },
      { name: "Young gentlemen", duration: "30 min", price: 40 },
      { name: "Senior Gentleman's", duration: "30 min", price: 45 },
      { name: "Beard trim", duration: "30 min", price: 30 }
    ]
  }
};

/* ---------- Mobile nav ---------- */

document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.getElementById("navToggle");
  var nav = document.getElementById("mainNav");

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });

    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  initTabs();
  initBooking();
});

/* ---------- Service tabs ---------- */

function activateTab(tabId) {
  var buttons = document.querySelectorAll(".tab-btn");
  var panels = document.querySelectorAll(".tab-panel");
  if (!buttons.length) return;

  buttons.forEach(function (btn) {
    var active = btn.getAttribute("data-tab") === tabId;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-selected", active ? "true" : "false");
  });

  panels.forEach(function (panel) {
    panel.classList.toggle("active", panel.id === "panel-" + tabId);
  });
}

function initTabs() {
  var buttons = document.querySelectorAll(".tab-btn");
  if (!buttons.length) return;

  buttons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      activateTab(btn.getAttribute("data-tab"));
    });
  });

  document.querySelectorAll("[data-jump]").forEach(function (link) {
    link.addEventListener("click", function () {
      activateTab(link.getAttribute("data-jump"));
    });
  });

  // Deep link: index.html#services with barber in query (from booking comparison link)
  var params = new URLSearchParams(window.location.search);
  var preselect = params.get("tab");
  if (preselect && BARBER_DATA[preselect]) {
    activateTab(preselect);
  }
}

/* ---------- Booking form ---------- */

function initBooking() {
  var form = document.getElementById("bookingForm");
  if (!form) return;

  var locationSel = document.getElementById("location");
  var barberSel = document.getElementById("barber");
  var serviceSel = document.getElementById("service");
  var serviceHint = document.getElementById("serviceHint");
  var dateInput = document.getElementById("date");
  var timeSel = document.getElementById("time");
  var notesHintOk = true;

  // Minimum date is today
  var today = new Date();
  var iso = today.getFullYear() + "-" +
    String(today.getMonth() + 1).padStart(2, "0") + "-" +
    String(today.getDate()).padStart(2, "0");
  dateInput.min = iso;

  // Time slots: 9:00 AM to 6:30 PM every 30 minutes
  var slots = [];
  for (var h = 9; h <= 18; h++) {
    for (var m = 0; m < 60; m += 30) {
      if (h === 18 && m === 30) break;
      var hour12 = h > 12 ? h - 12 : h;
      var suffix = h >= 12 ? "PM" : "AM";
      slots.push(hour12 + ":" + String(m).padStart(2, "0") + " " + suffix);
    }
  }
  slots.forEach(function (slot) {
    var opt = document.createElement("option");
    opt.value = slot;
    opt.textContent = slot;
    timeSel.appendChild(opt);
  });

  function selectedService() {
    var key = barberSel.value;
    if (!key || !BARBER_DATA[key]) return null;
    var name = serviceSel.value;
    return BARBER_DATA[key].services.find(function (s) { return s.name === name; }) || null;
  }

  function updateServiceOptions(keepSelection) {
    var key = barberSel.value;
    var previous = keepSelection ? serviceSel.value : "";
    serviceSel.innerHTML = "";

    if (!key || !BARBER_DATA[key]) {
      serviceSel.disabled = true;
      serviceSel.appendChild(new Option("Choose a barber first", ""));
      if (serviceHint) {
        serviceHint.textContent = "Duration and price appear once you pick a barber.";
      }
      return;
    }

    serviceSel.disabled = false;
    serviceSel.appendChild(new Option("Choose a service", ""));
    BARBER_DATA[key].services.forEach(function (s) {
      serviceSel.appendChild(new Option(s.name + " · " + s.duration + " · $" + s.price, s.name));
    });

    if (previous) {
      serviceSel.value = previous;
    }

    if (serviceHint) {
      serviceHint.textContent = BARBER_DATA[key].name + " offers " +
        BARBER_DATA[key].services.length + " services.";
    }
  }

  function formatDate(value) {
    if (!value) return "Not chosen";
    var parts = value.split("-");
    var d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    return d.toLocaleDateString("en-US", {
      weekday: "short", month: "short", day: "numeric", year: "numeric"
    });
  }

  function updateSummary() {
    var loc = locationSel.value;
    var barberKey = barberSel.value;
    var svc = selectedService();

    document.getElementById("sumLocation").textContent = loc || "Not chosen";
    document.getElementById("sumBarber").textContent =
      (barberKey && BARBER_DATA[barberKey]) ? BARBER_DATA[barberKey].name : "Not chosen";
    document.getElementById("sumService").textContent = svc ? svc.name : "Not chosen";
    document.getElementById("sumDuration").textContent = svc ? svc.duration : "-";
    document.getElementById("sumDate").textContent = formatDate(dateInput.value);
    document.getElementById("sumTime").textContent = timeSel.value || "Not chosen";
    document.getElementById("sumPrice").textContent = svc ? "$" + svc.price : "-";
  }

  barberSel.addEventListener("change", function () {
    updateServiceOptions(false);
    updateSummary();
  });

  [locationSel, serviceSel, dateInput, timeSel].forEach(function (el) {
    el.addEventListener("change", updateSummary);
    el.addEventListener("input", updateSummary);
  });

  // Preselect barber from URL: booking.html?barber=angel
  var params = new URLSearchParams(window.location.search);
  var preBarber = params.get("barber");
  if (preBarber && BARBER_DATA[preBarber]) {
    barberSel.value = preBarber;
    updateServiceOptions(false);
  } else {
    updateServiceOptions(false);
  }
  updateSummary();

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    var svc = selectedService();
    if (barberSel.value && !svc) {
      serviceSel.focus();
      serviceSel.setCustomValidity("Choose a service.");
      serviceSel.reportValidity();
      serviceSel.setCustomValidity("");
      return;
    }

    var barberKey = barberSel.value;
    var summary = document.getElementById("successSummary");
    var rows = [
      ["Location", locationSel.value],
      ["Barber", BARBER_DATA[barberKey].name],
      ["Service", svc.name],
      ["Duration", svc.duration],
      ["Price", "$" + svc.price],
      ["Date", formatDate(dateInput.value)],
      ["Time", timeSel.value],
      ["Name", document.getElementById("name").value],
      ["Phone", document.getElementById("phone").value]
    ];

    summary.innerHTML = "";
    rows.forEach(function (row) {
      var wrap = document.createElement("div");
      var label = document.createElement("span");
      var value = document.createElement("strong");
      label.textContent = row[0];
      value.textContent = row[1];
      wrap.appendChild(label);
      wrap.appendChild(value);
      summary.appendChild(wrap);
    });

    var box = document.getElementById("successBox");
    box.classList.add("show");
    box.scrollIntoView({ behavior: "smooth", block: "start" });
    form.reset();
    updateServiceOptions(false);
    updateSummary();

    // Reset date minimum after reset
    dateInput.min = iso;
  });
}
